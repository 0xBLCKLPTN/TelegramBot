from threading import Thread
from time import sleep
from datetime import datetime, timedelta
from core import config

class Subscriber:
    def __init__(self):
        self.seconds = config.START_LOOP
        self.need_s = datetime.now() + timedelta(seconds=self.seconds)
    def check(self):
        while True:
            
            if self.seconds != config.START_LOOP:
                self.seconds = config.START_LOOP
                self.need_s = datetime.now() + timedelta(seconds=self.seconds)
            
            if datetime.now() >= self.need_s:
                print('Готово!') # сюда функцию, которая должна выполняться

                self.need_s = datetime.now() + timedelta(seconds=self.seconds)
            sleep(1)


class BotTime:
    def __init__(self):
        self.seconds = config.START_BOT
        self.need_s = datetime.now() + timedelta(seconds=self.seconds)
    def check(self):
        while True:
            
            if self.seconds != config.START_BOT:
                self.seconds = config.START_BOT
                self.need_s = datetime.now() + timedelta(seconds=self.seconds)
            
            if datetime.now() >= self.need_s:
                print('Готово!') # сюда функцию, которая должна выполняться

                self.need_s = datetime.now() + timedelta(seconds=self.seconds)
            sleep(1)
        


def start_threads():
    sc = Subscriber()
    bt = BotTime()

    th1 = Thread(target=sc.check)
    th2 = Thread(target=bt.check)

    th1.start()
    th2.start()