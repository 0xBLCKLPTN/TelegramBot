from dispatcher import dp, bot
from aiogram import types
from utils.dataspace import *
from keyboards.start_menu import *
from aiogram.dispatcher import FSMContext 
from keyboards.states import *
from keyboards.admin_menu import *
from utils import validator
import core.config
from keyboards.load_files import *


@dp.message_handler(commands=["start"])
async def process_start_command(message: types.Message):
    if ManageAdmins().check_admin(user_id = str(message.from_user.id)):
        await message.reply("admin", reply_markup=admin_keyboard)
    else:
        if core.config.Bot_on:
            if  ManageUsers().check_user(message.from_user.id):
                await message.reply("Привет!", reply_markup=main_kb)
            else: 
                await message.reply("Привет! Тебе нужно зарегестрироваться!", reply_markup=start_kb)

"""@dp.message_handler(commands=["add"])
async def process_start_command(message: types.Message):
    admin = Admins(
    user_id = message.from_user.id
)
    ManageAdmins().add_admin(admin)"""

@dp.message_handler(text="Расценки", state="*")
async def description(message: types.Message):
    if core.config.Bot_on:
        await message.reply("Текст расценок", reply_markup=return_kb)

@dp.message_handler(text="Описание", state='*')
async def description(message: types.Message):
    if core.config.Bot_on:
        await message.reply("Текст описания", reply_markup=return_kb)
    

PRICE = types.LabeledPrice(label='Настоящая Машина Времени', amount=4200000)

@dp.message_handler(text="Оплата", state='*')
async def description(message: types.Message):
    if core.config.Bot_on:
        await message.reply("Текст описания", reply_markup=return_kb)
        await bot.send_invoice(
            message.chat.id,
            title='welcome',
            description='simple description',
            provider_token=settings.PAYMENT_TOKEN,
            currency='RUB',
            #photo_url=TIME_MACHINE_IMAGE_URL,
            #photo_height=512,  # !=0/None, иначе изображение не покажется
            #photo_width=512,
            #photo_size=512,
            is_flexible=False,  # True если конечная цена зависит от способа доставки
            prices=[PRICE],
            start_parameter='callback_query',
            payload='callback_query'
)




@dp.pre_checkout_query_handler()
async def process_pre_checkout_query(pre_checkout_query: types.PreCheckoutQuery):
    await bot.answer_pre_checkout_query(pre_checkout_query.id, ok=True)

@dp.message_handler(content_types=types.ContentType.SUCCESSFUL_PAYMENT)
async def process_pay(message: types.Message):
    if message.successful_payment.invoice_payload == "callback_query":
        dataspace.ManageUsers().new_pay(message.from_user.id)
        await message.reply('Ты успешно подписан!')


@dp.message_handler(text="Инструкция по настройке", state='*')
async def description(message: types.Message):
    if core.config.Bot_on:
        with open(settings.INSTRUCTIONS_FILE) as file:
            text = file.read()

        await message.reply(text, reply_markup=return_kb)

@dp.message_handler(text="Вопросы и пожелания", state='*')
async def description(message: types.Message):
    if core.config.Bot_on:
        await message.reply("Вы можете написать свой вопрос или пожелание по работе бота, мы постараемся ответит Вам в ближайшее время", reply_markup=return_kb)

@dp.message_handler(text="Вернуться", state='*')
async def description(message: types.Message):
    if core.config.Bot_on:
        await message.answer("Привет!",reply_markup=main_kb)